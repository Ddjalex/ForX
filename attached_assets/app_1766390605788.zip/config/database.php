<?php

// Support both PostgreSQL and MySQL
$driver = getenv('DB_DRIVER') ?: 'mysql';

$config = [
    'driver' => $driver,
    'host' => getenv('DB_HOST') ?: 'localhost',
    'port' => getenv('DB_PORT') ?: ($driver === 'pgsql' ? 5432 : 3306),
    'database' => getenv('DB_NAME'),
    'username' => getenv('DB_USER'),
    'password' => getenv('DB_PASS'),
];

// For PostgreSQL
if ($driver === 'pgsql') {
    $config['host'] = getenv('PGHOST') ?: $config['host'];
    $config['port'] = getenv('PGPORT') ?: $config['port'];
    $config['database'] = getenv('PGDATABASE') ?: $config['database'];
    $config['username'] = getenv('PGUSER') ?: $config['username'];
    $config['password'] = getenv('PGPASSWORD') ?: $config['password'];
}

return $config;
