<?php

namespace App\Controllers;

use App\Services\Auth;
use App\Services\Database;
use App\Services\Router;
use App\Services\Session;
use App\Services\AuditLog;

class TradingController
{
    /**
     * Normalize market type to your UI standard
     * (keep only: Crypto / Forex / Stocks)
     */
    private function normalizeType(?string $type): string
    {
        $t = trim((string)$type);

        // Common variants
        if (strcasecmp($t, 'Cryptocurrency') === 0) return 'Crypto';
        if (strcasecmp($t, 'Crypto') === 0) return 'Crypto';

        if (strcasecmp($t, 'Forex') === 0) return 'Forex';
        if (strcasecmp($t, 'FX') === 0) return 'Forex';

        if (strcasecmp($t, 'Stock') === 0) return 'Stocks';
        if (strcasecmp($t, 'Stocks') === 0) return 'Stocks';
        if (strcasecmp($t, 'Equities') === 0) return 'Stocks';

        // Default fallback (still show something)
        return $t !== '' ? $t : 'Crypto';
    }

    /**
     * Preferred order in dropdowns
     */
    private function typeOrderSql(): string
    {
        // Add more if you have, but keep your UI stable
        return "FIELD(m.type,'Crypto','Forex','Stocks')";
    }

    public function markets(): void
    {
        $markets = Database::fetchAll(
            "SELECT m.*, p.price, p.change_24h
             FROM markets m
             LEFT JOIN prices p ON m.id = p.market_id
             WHERE m.status = 'active'
             ORDER BY {$this->typeOrderSql()}, m.symbol"
        );

        echo Router::render('trading/markets', [
            'markets' => $markets,
            'csrf_token' => Session::generateCsrfToken(),
        ]);
    }

    public function tradeDefault(): void
    {
        // Pick first active market by type order + symbol
        $market = Database::fetch(
            "SELECT m.*, p.price, p.change_24h, p.high_24h, p.low_24h, p.volume_24h
             FROM markets m
             LEFT JOIN prices p ON m.id = p.market_id
             WHERE m.status = 'active'
             ORDER BY {$this->typeOrderSql()}, m.symbol
             LIMIT 1"
        );

        if (!$market) {
            Router::redirect('/dashboard');
            return;
        }

        $market['type'] = $this->normalizeType($market['type'] ?? null);
        $this->renderTrade($market);
    }

    public function trade(string $symbol): void
    {
        $market = Database::fetch(
            "SELECT m.*, p.price, p.change_24h, p.high_24h, p.low_24h, p.volume_24h
             FROM markets m
             LEFT JOIN prices p ON m.id = p.market_id
             WHERE m.symbol = ? AND m.status = 'active'
             LIMIT 1",
            [$symbol]
        );

        if (!$market) {
            Router::redirect('/dashboard/trade');
            return;
        }

        $market['type'] = $this->normalizeType($market['type'] ?? null);
        $this->renderTrade($market);
    }

    private function renderTrade(array $market): void
    {
        $user   = Auth::user();
        $wallet = Database::fetch("SELECT * FROM wallets WHERE user_id = ?", [$user['id']]);

        // ✅ DB is the ONLY source of truth for dropdown + TradingView symbol
        $allMarkets = Database::fetchAll(
            "SELECT
                m.id,
                m.type,
                m.symbol,
                m.name,
                m.tv_symbol,
                m.min_trade_size,
                m.max_leverage,
                m.spread,
                m.fee,
                m.status,
                p.price,
                p.change_24h,
                p.high_24h,
                p.low_24h,
                p.volume_24h
             FROM markets m
             LEFT JOIN prices p ON p.market_id = m.id
             WHERE m.status = 'active'
             ORDER BY {$this->typeOrderSql()}, m.symbol"
        );

        // Normalize types for every market row
        foreach ($allMarkets as &$m) {
            $m['type'] = $this->normalizeType($m['type'] ?? null);
        }
        unset($m);

        // Ensure selected market type is normalized too
        $market['type'] = $this->normalizeType($market['type'] ?? null);

        // Build assetTypes array exactly as your view expects:
        // $type['name'] and $type['display_name']
        $assetTypes = [];
        $seen = [];

        foreach ($allMarkets as $m) {
            $t = $m['type'];
            if (!isset($seen[$t])) {
                $seen[$t] = true;
                $assetTypes[] = [
                    'name' => $t,
                    'display_name' => $t,
                ];
            }
        }

        // Optional: group markets by type (if you want later)
        $marketsByType = [];
        foreach ($allMarkets as $m) {
            $marketsByType[$m['type']][] = $m;
        }

        $openPositions = Database::fetchAll(
            "SELECT p.*, m.symbol, m.name AS market_name
             FROM positions p
             JOIN markets m ON p.market_id = m.id
             WHERE p.user_id = ? AND p.status = 'open'
             ORDER BY p.created_at DESC",
            [$user['id']]
        );

        $closedPositions = Database::fetchAll(
            "SELECT p.*, m.symbol, m.name AS market_name
             FROM positions p
             JOIN markets m ON p.market_id = m.id
             WHERE p.user_id = ? AND p.status = 'closed'
             ORDER BY p.closed_at DESC
             LIMIT 50",
            [$user['id']]
        );

        $pendingOrders = Database::fetchAll(
            "SELECT * FROM orders
             WHERE user_id = ? AND market_id = ? AND status = 'pending'
             ORDER BY created_at DESC",
            [$user['id'], $market['id']]
        );

        // ✅ FIX: price_history query must not contain "?"
        // your phpMyAdmin error happened because you ran it directly with placeholder.
        $priceHistory = Database::fetchAll(
            "SELECT price, ts AS created_at
             FROM prices_history
             WHERE market_id = ?
             ORDER BY ts DESC
             LIMIT 100",
            [$market['id']]
        );

        echo Router::render('trading/trade', [
            'user' => $user,
            'market' => $market,
            'wallet' => $wallet,

            'allMarkets' => $allMarkets,
            'assetTypes' => $assetTypes,
            'marketsByType' => $marketsByType,

            'openPositions' => $openPositions,
            'closedPositions' => $closedPositions,
            'pendingOrders' => $pendingOrders,
            'priceHistory' => array_reverse($priceHistory),

            'csrf_token' => Session::generateCsrfToken(),
            'error' => Session::getFlash('error'),
            'success' => Session::getFlash('success'),
        ]);
    }

    public function placeOrder(): void
    {
        $isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';

        $csrfToken = $_POST['_csrf_token'] ?? '';
        if (!empty($csrfToken) && !Session::validateCsrfToken($csrfToken)) {
            Router::json(['error' => 'Invalid request. Please reload and try again.'], 403);
            return;
        }

        $userId    = Auth::id();
        $marketId  = filter_input(INPUT_POST, 'market_id', FILTER_VALIDATE_INT);
        $orderType = filter_input(INPUT_POST, 'order_type', FILTER_SANITIZE_SPECIAL_CHARS);
        $side      = filter_input(INPUT_POST, 'side', FILTER_SANITIZE_SPECIAL_CHARS);
        $amount    = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
        $leverage  = filter_input(INPUT_POST, 'leverage', FILTER_VALIDATE_INT) ?: 1;
        $price     = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
        $stopLoss  = filter_input(INPUT_POST, 'stop_loss', FILTER_VALIDATE_FLOAT);
        $takeProfit= filter_input(INPUT_POST, 'take_profit', FILTER_VALIDATE_FLOAT);
        $duration  = filter_input(INPUT_POST, 'duration', FILTER_VALIDATE_INT) ?: 1;

        if (!$marketId || !$orderType || !$side || !$amount) {
            $error = 'Please fill in all required fields.';
            if ($isAjax) Router::json(['error' => $error], 400);
            Session::flash('error', $error);
            Router::redirect($_SERVER['HTTP_REFERER'] ?? '/dashboard/trade');
            return;
        }

        $market = Database::fetch("SELECT * FROM markets WHERE id = ? AND status = 'active' LIMIT 1", [$marketId]);
        if (!$market) {
            $error = 'Invalid market.';
            if ($isAjax) Router::json(['error' => $error], 400);
            Session::flash('error', $error);
            Router::redirect('/dashboard/trade');
            return;
        }

        if ($leverage > (int)$market['max_leverage']) {
            $error = "Maximum leverage for this market is {$market['max_leverage']}x.";
            if ($isAjax) Router::json(['error' => $error], 400);
            Session::flash('error', $error);
            Router::redirect($_SERVER['HTTP_REFERER'] ?? '/dashboard/trade');
            return;
        }

        if ($amount < (float)$market['min_trade_size']) {
            $error = "Minimum trade size is {$market['min_trade_size']}.";
            if ($isAjax) Router::json(['error' => $error], 400);
            Session::flash('error', $error);
            Router::redirect($_SERVER['HTTP_REFERER'] ?? '/dashboard/trade');
            return;
        }

        $wallet       = Database::fetch("SELECT * FROM wallets WHERE user_id = ? LIMIT 1", [$userId]);
        $currentPrice = Database::fetch("SELECT price FROM prices WHERE market_id = ? LIMIT 1", [$marketId]);

        $entryPrice = (float)($currentPrice['price'] ?? 0);
        if ($orderType === 'limit' && $price) {
            $entryPrice = (float)$price;
        }

        $marginRequired   = ($amount * $entryPrice) / max(1, $leverage);
        $availableBalance = (float)$wallet['balance'] - (float)$wallet['margin_used'];

        if ($marginRequired > $availableBalance) {
            $error = 'Insufficient margin. Required: $' . number_format($marginRequired, 2);
            if ($isAjax) Router::json(['error' => $error], 400);
            Session::flash('error', $error);
            Router::redirect($_SERVER['HTTP_REFERER'] ?? '/dashboard/trade');
            return;
        }

        if ($orderType === 'market') {
            $spread = (float)($market['spread'] ?? 0);
            $executionPrice = $side === 'buy'
                ? $entryPrice * (1 + $spread)
                : $entryPrice * (1 - $spread);

            $createdAt = date('Y-m-d H:i:s');
            $expiresAt = date('Y-m-d H:i:s', strtotime("+{$duration} minutes"));

            $recentDuplicate = Database::fetch(
                "SELECT id
                 FROM positions
                 WHERE user_id = ? AND market_id = ? AND side = ? AND amount = ? AND leverage = ?
                 AND created_at > (NOW() - INTERVAL 2 SECOND)
                 ORDER BY id DESC
                 LIMIT 1",
                [$userId, $marketId, $side, $amount, $leverage]
            );

            if ($recentDuplicate) {
                Session::flash('success', 'Trade executed successfully. You can review it in your trade history.');
                Router::redirect('/dashboard/trades/history');
                return;
            }

            $positionId = Database::insert('positions', [
                'user_id' => $userId,
                'market_id' => $marketId,
                'side' => $side,
                'amount' => $amount,
                'entry_price' => $executionPrice,
                'leverage' => $leverage,
                'margin_used' => $marginRequired,
                'stop_loss' => $stopLoss ?: null,
                'take_profit' => $takeProfit ?: null,
                'status' => 'open',
                'duration' => $duration,
                'expires_at' => $expiresAt,
                'created_at' => $createdAt,
            ]);

            Database::update('wallets', [
                'margin_used' => (float)$wallet['margin_used'] + $marginRequired,
            ], 'user_id = ?', [$userId]);

            Database::insert('trades', [
                'user_id' => $userId,
                'position_id' => $positionId,
                'market_id' => $marketId,
                'side' => $side,
                'amount' => $amount,
                'price' => $executionPrice,
                'fee' => $amount * $executionPrice * (float)($market['fee'] ?? 0.001),
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            AuditLog::log('open_position', 'position', $positionId, [
                'market' => $market['symbol'],
                'side' => $side,
                'amount' => $amount,
                'price' => $executionPrice,
                'leverage' => $leverage,
            ]);

            Session::flash('success', 'Trade executed successfully. You can review it in your trade history.');
            Router::redirect('/dashboard/trades/history');
            return;
        }

        // limit / pending order
        Database::insert('orders', [
            'user_id' => $userId,
            'market_id' => $marketId,
            'type' => $orderType,
            'side' => $side,
            'amount' => $amount,
            'price' => $price,
            'leverage' => $leverage,
            'stop_loss' => $stopLoss ?: null,
            'take_profit' => $takeProfit ?: null,
            'margin_reserved' => $marginRequired,
            'status' => 'pending',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        Database::update('wallets', [
            'margin_used' => (float)$wallet['margin_used'] + $marginRequired,
        ], 'user_id = ?', [$userId]);

        AuditLog::log('place_order', 'order', null, [
            'market' => $market['symbol'],
            'type' => $orderType,
            'side' => $side,
            'amount' => $amount,
            'price' => $price,
        ]);

        Session::flash('success', 'Order placed successfully.');
        Router::redirect("/dashboard/trade/{$market['symbol']}");
    }

    public function closePosition(): void
    {
        $csrfToken = $_POST['_csrf_token'] ?? '';
        if (empty($csrfToken) || !Session::validateCsrfToken($csrfToken)) {
            Router::json(['error' => 'Invalid request. Please reload and try again.'], 403);
            return;
        }

        $userId = Auth::id();
        $positionId = filter_input(INPUT_POST, 'position_id', FILTER_VALIDATE_INT);

        $position = Database::fetch(
            "SELECT p.*, m.symbol, m.spread
             FROM positions p
             JOIN markets m ON p.market_id = m.id
             WHERE p.id = ? AND p.user_id = ? AND p.status = 'open'
             LIMIT 1",
            [$positionId, $userId]
        );

        if (!$position) {
            Session::flash('error', 'Position not found.');
            Router::redirect('/dashboard');
            return;
        }

        $currentPrice = Database::fetch("SELECT price FROM prices WHERE market_id = ? LIMIT 1", [$position['market_id']]);
        $exitPrice = (float)($currentPrice['price'] ?? $position['entry_price']);

        $spread = (float)($position['spread'] ?? 0);
        $exitPrice = $position['side'] === 'buy'
            ? $exitPrice * (1 - $spread)
            : $exitPrice * (1 + $spread);

        $pnl = ($position['side'] === 'buy')
            ? ($exitPrice - (float)$position['entry_price']) * (float)$position['amount']
            : (((float)$position['entry_price'] - $exitPrice) * (float)$position['amount']);

        $profitControlPercent = Database::fetch("SELECT value FROM settings WHERE `key` = ? LIMIT 1", ['profit_control_percent']);
        $controlPercent = $profitControlPercent ? (float)$profitControlPercent['value'] : 0.0;

        $mult = 1 + ($controlPercent / 100);
        $adjustedPnl = $pnl * $mult;

        Database::update('positions', [
            'exit_price' => $exitPrice,
            'realized_pnl' => $adjustedPnl,
            'status' => 'closed',
            'closed_at' => date('Y-m-d H:i:s'),
        ], 'id = ?', [$positionId]);

        $wallet = Database::fetch("SELECT * FROM wallets WHERE user_id = ? LIMIT 1", [$userId]);
        Database::update('wallets', [
            'balance' => (float)$wallet['balance'] + $adjustedPnl,
            'margin_used' => (float)$wallet['margin_used'] - (float)$position['margin_used'],
        ], 'user_id = ?', [$userId]);

        AuditLog::log('close_position', 'position', $positionId, [
            'market' => $position['symbol'],
            'original_pnl' => $pnl,
            'adjusted_pnl' => $adjustedPnl,
            'profit_control_percent' => $controlPercent,
            'exit_price' => $exitPrice,
        ]);

        Session::flash('success', 'Position closed. PnL: $' . number_format($adjustedPnl, 2));
        Router::redirect("/dashboard/trade/{$position['symbol']}");
    }

    public function cancelOrder(): void
    {
        $csrfToken = $_POST['_csrf_token'] ?? '';
        if (empty($csrfToken) || !Session::validateCsrfToken($csrfToken)) {
            Router::json(['error' => 'Invalid request. Please reload and try again.'], 403);
            return;
        }

        $userId = Auth::id();
        $orderId = filter_input(INPUT_POST, 'order_id', FILTER_VALIDATE_INT);

        $order = Database::fetch(
            "SELECT o.*, m.symbol
             FROM orders o
             JOIN markets m ON o.market_id = m.id
             WHERE o.id = ? AND o.user_id = ? AND o.status = 'pending'
             LIMIT 1",
            [$orderId, $userId]
        );

        if (!$order) {
            Session::flash('error', 'Order not found.');
            Router::redirect('/dashboard');
            return;
        }

        Database::update('orders', ['status' => 'cancelled'], 'id = ?', [$orderId]);

        $wallet = Database::fetch("SELECT * FROM wallets WHERE user_id = ? LIMIT 1", [$userId]);
        Database::update('wallets', [
            'margin_used' => (float)$wallet['margin_used'] - (float)$order['margin_reserved'],
        ], 'user_id = ?', [$userId]);

        AuditLog::log('cancel_order', 'order', $orderId, ['market' => $order['symbol']]);

        Session::flash('success', 'Order cancelled successfully.');
        Router::redirect("/dashboard/trade/{$order['symbol']}");
    }

    public function positions(): void
    {
        $userId = Auth::id();

        $openPositions = Database::fetchAll(
            "SELECT p.*, m.symbol, m.name as market_name
             FROM positions p
             JOIN markets m ON p.market_id = m.id
             WHERE p.user_id = ? AND p.status = 'open'
             ORDER BY p.created_at DESC",
            [$userId]
        );

        $closedPositions = Database::fetchAll(
            "SELECT p.*, m.symbol, m.name as market_name
             FROM positions p
             JOIN markets m ON p.market_id = m.id
             WHERE p.user_id = ? AND p.status = 'closed'
             ORDER BY p.closed_at DESC
             LIMIT 50",
            [$userId]
        );

        echo Router::render('trading/positions', [
            'openPositions' => $openPositions,
            'closedPositions' => $closedPositions,
            'csrf_token' => Session::generateCsrfToken(),
        ]);
    }

    public function orders(): void
    {
        $userId = Auth::id();

        $pendingOrders = Database::fetchAll(
            "SELECT o.*, m.symbol, m.name as market_name
             FROM orders o
             JOIN markets m ON o.market_id = m.id
             WHERE o.user_id = ? AND o.status = 'pending'
             ORDER BY o.created_at DESC",
            [$userId]
        );

        $orderHistory = Database::fetchAll(
            "SELECT o.*, m.symbol, m.name as market_name
             FROM orders o
             JOIN markets m ON o.market_id = m.id
             WHERE o.user_id = ? AND o.status != 'pending'
             ORDER BY o.created_at DESC
             LIMIT 50",
            [$userId]
        );

        echo Router::render('trading/orders', [
            'pendingOrders' => $pendingOrders,
            'orderHistory' => $orderHistory,
            'csrf_token' => Session::generateCsrfToken(),
        ]);
    }

    public function history(): void
    {
        $userId = Auth::id();

        $positions = Database::fetchAll(
            "SELECT p.*, m.symbol, m.name as market_name
             FROM positions p
             JOIN markets m ON p.market_id = m.id
             WHERE p.user_id = ?
             ORDER BY p.created_at DESC",
            [$userId]
        );

        echo Router::render('trading/history', [
            'positions' => $positions,
            'csrf_token' => Session::generateCsrfToken(),
            'success' => Session::getFlash('success'),
            'error' => Session::getFlash('error'),
        ]);
    }

    public function copyExperts(): void
    {
        $copyTradingService = new \App\Services\CopyTradingService();
        $traders = $copyTradingService->getTopTraders(12);

        echo Router::render('trading/copy-experts', [
            'traders' => $traders,
            'csrf_token' => Session::generateCsrfToken(),
        ]);
    }
}
