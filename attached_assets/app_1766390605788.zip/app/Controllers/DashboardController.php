<?php

namespace App\Controllers;

use App\Services\Auth;
use App\Services\Database;
use App\Services\Router;
use App\Services\Session;

    class DashboardController
    {
    public function index(): void
    {
    if (!Auth::check()) {
        Router::redirect('/login');
        return;
    }

    $user = Auth::user();


        // Get wallet (or create defaults)
        $wallet = Database::fetch("SELECT * FROM wallets WHERE user_id = ?", [$user['id']]);
        if (!is_array($wallet)) {
            $wallet = [
                'id' => null,
                'user_id' => $user['id'],
                'balance' => 0,
                'margin_used' => 0,
                'profit' => 0,
                'bonus' => 0
            ];
        }

        // Open positions
        $openPositions = Database::fetchAll(
            "SELECT p.*, m.symbol, m.name as market_name
             FROM positions p
             JOIN markets m ON p.market_id = m.id
             WHERE p.user_id = ? AND p.status = 'open'
             ORDER BY p.created_at DESC",
            [$user['id']]
        );
        if (!is_array($openPositions)) $openPositions = [];

        // Closed positions
        $closedPositions = Database::fetchAll(
            "SELECT p.*, m.symbol, m.name as market_name
             FROM positions p
             JOIN markets m ON p.market_id = m.id
             WHERE p.user_id = ? AND p.status = 'closed'
             ORDER BY p.closed_at DESC",
            [$user['id']]
        );
        if (!is_array($closedPositions)) $closedPositions = [];

        // Recent transactions
        $recentTransactions = Database::fetchAll(
            "SELECT 'deposit' as type, amount, status, created_at FROM deposits WHERE user_id = ?
             UNION ALL
             SELECT 'withdrawal' as type, amount, status, created_at FROM withdrawals WHERE user_id = ?
             ORDER BY created_at DESC LIMIT 10",
            [$user['id'], $user['id']]
        );
        if (!is_array($recentTransactions)) $recentTransactions = [];

        // ✅ Safe totalPnL (if unrealized_pnl missing)
        $totalPnL = 0.0;
        foreach ($openPositions as $p) {
            $totalPnL += (float)($p['unrealized_pnl'] ?? 0);
        }

        $totalTrades  = count($openPositions) + count($closedPositions);
        $openTrades   = count($openPositions);
        $closedTrades = count($closedPositions);

        $wins = array_filter($closedPositions, function ($p) {
            return ((float)($p['pnl'] ?? 0)) > 0;
        });

        $winCount = count($wins);
        $lossCount = $closedTrades - $winCount;
        $winLossRatio = $lossCount > 0 ? round($winCount / $lossCount, 1) : $winCount;

        // Profit from closed trades
        $profit = 0.0;
        foreach ($closedPositions as $p) {
            $profit += (float)($p['pnl'] ?? 0);
        }

        // Fill wallet fields safely
        if (!isset($wallet['profit'])) $wallet['profit'] = $profit;
        if (!isset($wallet['bonus']))  $wallet['bonus'] = 0;

        $stats = [
            'total_trades'   => $totalTrades,
            'open_trades'    => $openTrades,
            'closed_trades'  => $closedTrades,
            'win_loss_ratio' => $winLossRatio,
        ];

        // Crypto markets
        $cryptoMarkets = Database::fetchAll(
            "SELECT m.*, p.price, p.change_24h, p.high_24h, p.low_24h, p.volume_24h
             FROM markets m
             LEFT JOIN prices p ON m.id = p.market_id
             WHERE m.type = 'crypto' AND m.status = 'active'
             ORDER BY p.volume_24h DESC"
        );
        if (!is_array($cryptoMarkets)) $cryptoMarkets = [];

        // Forex/stocks/indices
        $stockMarkets = Database::fetchAll(
            "SELECT m.*, p.price, p.change_24h, p.high_24h, p.low_24h, p.volume_24h
             FROM markets m
             LEFT JOIN prices p ON m.id = p.market_id
             WHERE m.type IN ('forex', 'stocks', 'indices') AND m.status = 'active'
             ORDER BY m.symbol"
        );
        if (!is_array($stockMarkets)) $stockMarkets = [];

        echo Router::render('user/dashboard', [
            'user' => $user,
            'wallet' => $wallet,
            'openPositions' => $openPositions,
            'closedPositions' => $closedPositions,
            'recentTransactions' => $recentTransactions,
            'totalPnL' => $totalPnL,
            'stats' => $stats,
            'cryptoMarkets' => $cryptoMarkets,
            'stockMarkets' => $stockMarkets,
            'csrf_token' => Session::generateCsrfToken(),
        ]);
    }
}
