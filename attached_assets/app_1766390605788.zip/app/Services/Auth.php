<?php

namespace App\Services;

use App\Services\Database;
use App\Services\Session;

class Auth
{
    /**
     * Attempt login
     */
    public static function attempt(string $email, string $password): bool|string
    {
        $user = Database::fetch(
            "SELECT * FROM users WHERE email = ? AND status = 'active' LIMIT 1",
            [$email]
        );

        if ($user && password_verify($password, $user['password'])) {

            // Email not verified
            if (empty($user['email_verified'])) {
                self::logLogin((int)$user['id'], false);
                return 'unverified';
            }

            self::login($user);
            self::logLogin((int)$user['id'], true);
            return true;
        }

        if ($user) {
            self::logLogin((int)$user['id'], false);
        }

        return false;
    }

    /**
     * Login user (SESSION STORAGE)
     */
    public static function login(array $user): void
    {
        Session::set('user_id', (int)$user['id']);
        Session::set('user_email', $user['email']);
        Session::set('user_role', $user['role'] ?? 'user');
        Session::set('logged_in', true);

        Database::update(
            'users',
            ['last_login' => date('Y-m-d H:i:s')],
            'id = ?',
            [$user['id']]
        );
    }

    /**
     * Logout user
     */
    public static function logout(): void
    {
        Session::destroy();
    }

    /**
     * Is user logged in?
     */
    public static function check(): bool
    {
        return (bool) Session::get('user_id');
    }

    /**
     * Get authenticated user
     */
    public static function user(): ?array
    {
        $userId = Session::get('user_id');
        if (!$userId) {
            return null;
        }

        return Database::fetch(
            "SELECT * FROM users WHERE id = ? LIMIT 1",
            [$userId]
        );
    }

    /**
     * Get authenticated user ID
     */
    public static function id(): ?int
    {
        $userId = Session::get('user_id');
        return $userId ? (int)$userId : null;
    }

    /**
     * Admin check
     */
    public static function isAdmin(): bool
    {
        $role = Session::get('user_role', 'user');
        return in_array($role, [
            'admin',
            'superadmin',
            'finance_admin',
            'support_admin'
        ], true);
    }

    /**
     * Super admin check
     */
    public static function isSuperAdmin(): bool
    {
        return Session::get('user_role') === 'superadmin';
    }

    /**
     * Log login attempts
     */
    private static function logLogin(int $userId, bool $success): void
    {
        Database::insert('login_logs', [
            'user_id'    => $userId,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'success'    => $success ? 1 : 0,
            'created_at'=> date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Register user
     */
    public static function register(array $data): int
    {
        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);

        $userData = [
            'name'            => $data['name'],
            'email'           => $data['email'],
            'password'        => $hashedPassword,
            'status'          => 'active',
            'role'            => 'user',
            'email_verified'  => $data['email_verified'] ?? 0,
            'created_at'      => date('Y-m-d H:i:s'),
        ];

        if (!empty($data['verification_code'])) {
            $userData['verification_code'] = $data['verification_code'];
        }

        if (!empty($data['verification_expires'])) {
            $userData['verification_expires'] = $data['verification_expires'];
        }

        return Database::insert('users', $userData);
    }

    /**
     * Check email verification
     */
    public static function isEmailVerified(string $email): bool
    {
        $user = Database::fetch(
            "SELECT email_verified FROM users WHERE email = ? LIMIT 1",
            [$email]
        );

        return !empty($user['email_verified']);
    }
}
