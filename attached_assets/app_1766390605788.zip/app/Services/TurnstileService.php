<?php

namespace App\Services;

class TurnstileService
{
    public static function getSiteKey(): string
    {
        return getenv('TURNSTILE_SITE_KEY')
            ?: getenv('CF_TURNSTILE_SITE_KEY')
            ?: '';
    }

    private static function getSecretKey(): string
    {
        return getenv('TURNSTILE_SECRET_KEY')
            ?: getenv('CF_TURNSTILE_SECRET_KEY')
            ?: '';
    }

    public static function verify(string $token): bool
    {
        $secret = self::getSecretKey();
        if ($secret === '' || $token === '') return false;

        $data = http_build_query([
            'secret'   => $secret,
            'response' => $token,
            'remoteip' => $_SERVER['REMOTE_ADDR'] ?? null,
        ]);

        $ch = curl_init('https://challenges.cloudflare.com/turnstile/v0/siteverify');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
        ]);

        $resp = curl_exec($ch);
        curl_close($ch);

        if (!$resp) return false;

        $json = json_decode($resp, true);
        return !empty($json['success']);
    }
}
